browser.contextMenus.create({
    id: "lori",
    title: "L or I or 1",
    contexts: ["selection"]
});

browser.contextMenus.onClicked.addListener(function(info, tab) {
    browser.tabs.sendMessage(
        tab.id, {
            message: info.selectionText.toUpperCase()
        }
    );
});